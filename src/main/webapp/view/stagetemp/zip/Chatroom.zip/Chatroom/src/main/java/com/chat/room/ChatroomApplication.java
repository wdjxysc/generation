package com.chat.room;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
/**
 * @ClassName:  ChatroomApplication   
 * @Description:TODO(启动入口)   
 * @author: generation
 * @date:   2019年07月06日 03:34:126
 * @Copyright: generation
 */
@SpringBootApplication
@ServletComponentScan()
public class ChatroomApplication extends SpringBootServletInitializer{

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ChatroomApplication.class);
    }

	public static void main(String[] args) {
		SpringApplication.run(ChatroomApplication.class, args);
	}

}