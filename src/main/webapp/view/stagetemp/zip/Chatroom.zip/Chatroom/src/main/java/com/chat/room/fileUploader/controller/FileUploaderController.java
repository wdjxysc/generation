package com.chat.room.fileUploader.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import com.chat.room.fileUploader.service.FileUploaderService;
import com.chat.room.fileUploader.vo.FileUploaderVO;
import java.util.List;
import com.chat.room.framework.config.ResponseModel;




@RequestMapping("/fileUploader")
@Controller
public class FileUploaderController {

	@Autowired
	private FileUploaderService fileUploaderService;
	
	@RequestMapping(value="/insert.do", method=RequestMethod.PUT)
	@ResponseBody
	public ResponseModel insertFileUploader(FileUploaderVO fileUploader, HttpServletRequest request, HttpServletResponse response){
		fileUploaderService.insertFileUploader(fileUploader);
		return ResponseModel.success("新增成功");
	}
	
	
	@RequestMapping(value="/delete.do", method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseModel deleteFileUploader(FileUploaderVO fileUploader, HttpServletRequest request, HttpServletResponse response){
		fileUploaderService.deleteFileUploader(fileUploader);
		return ResponseModel.success("删除成功");
	}
	
	
	@RequestMapping(value="/update.do", method=RequestMethod.POST)
	@ResponseBody
	public ResponseModel updateFileUploader(FileUploaderVO fileUploader, HttpServletRequest request, HttpServletResponse response){
		fileUploaderService.updateFileUploader(fileUploader);
		return ResponseModel.success("更新成功");
	}
	
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	@ResponseBody
	public ResponseModel listFileUploader(FileUploaderVO fileUploader, HttpServletRequest request, HttpServletResponse response){
		List<FileUploaderVO> list = fileUploaderService.listFileUploader(fileUploader);
		return ResponseModel.success(list);
	}
}

