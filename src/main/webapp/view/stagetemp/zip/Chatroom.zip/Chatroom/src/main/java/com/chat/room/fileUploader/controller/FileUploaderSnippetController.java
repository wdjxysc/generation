package com.chat.room.fileUploader.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import com.chat.room.fileUploader.service.FileUploaderSnippetService;
import com.chat.room.fileUploader.vo.FileUploaderSnippetVO;
import java.util.List;
import com.chat.room.framework.config.ResponseModel;




@RequestMapping("/fileUploaderSnippet")
@Controller
public class FileUploaderSnippetController {

	@Autowired
	private FileUploaderSnippetService fileUploaderSnippetService;
	
	@RequestMapping(value="/insert.do", method=RequestMethod.PUT)
	@ResponseBody
	public ResponseModel insertFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet, HttpServletRequest request, HttpServletResponse response){
		fileUploaderSnippetService.insertFileUploaderSnippet(fileUploaderSnippet);
		return ResponseModel.success("新增成功");
	}
	
	
	@RequestMapping(value="/delete.do", method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseModel deleteFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet, HttpServletRequest request, HttpServletResponse response){
		fileUploaderSnippetService.deleteFileUploaderSnippet(fileUploaderSnippet);
		return ResponseModel.success("删除成功");
	}
	
	
	@RequestMapping(value="/update.do", method=RequestMethod.POST)
	@ResponseBody
	public ResponseModel updateFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet, HttpServletRequest request, HttpServletResponse response){
		fileUploaderSnippetService.updateFileUploaderSnippet(fileUploaderSnippet);
		return ResponseModel.success("更新成功");
	}
	
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	@ResponseBody
	public ResponseModel listFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet, HttpServletRequest request, HttpServletResponse response){
		List<FileUploaderSnippetVO> list = fileUploaderSnippetService.listFileUploaderSnippet(fileUploaderSnippet);
		return ResponseModel.success(list);
	}
}

