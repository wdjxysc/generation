package com.chat.room.fileUploader.dao;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import com.chat.room.fileUploader.vo.FileUploaderVO;
import java.util.List;
/**   
 * @formatClassName:  FileUploaderDAO   
 * @Description:TODO(持久层接口)   
 * @author: generation
 * @date:   2019年07月06日 03:34:156
 * @Copyright: generation
 */
@Mapper
@Repository
public interface FileUploaderDAO {
	
	void insertFileUploader(FileUploaderVO fileUploader);
	
	void deleteFileUploader(FileUploaderVO fileUploader);
	
	void updateFileUploader(FileUploaderVO fileUploader);
	
	List<FileUploaderVO> listFileUploader(FileUploaderVO fileUploader);
}
