package com.chat.room.fileUploader.dao;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import com.chat.room.fileUploader.vo.FileUploaderSnippetVO;
import java.util.List;
/**   
 * @formatClassName:  FileUploaderSnippetDAO   
 * @Description:TODO(持久层接口)   
 * @author: generation
 * @date:   2019年07月06日 03:34:150
 * @Copyright: generation
 */
@Mapper
@Repository
public interface FileUploaderSnippetDAO {
	
	void insertFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
	
	void deleteFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
	
	void updateFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
	
	List<FileUploaderSnippetVO> listFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
}
