package com.chat.room.fileUploader.service;

import com.chat.room.fileUploader.vo.FileUploaderVO;
import java.util.List;
/**   
 * @formatClassName:  FileUploaderDAO   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月06日 03:34:156
 * @Copyright: generation
 */
public interface FileUploaderService {
	
	void insertFileUploader(FileUploaderVO fileUploader);
	
	void deleteFileUploader(FileUploaderVO fileUploader);
	
	void updateFileUploader(FileUploaderVO fileUploader);
	
	List<FileUploaderVO> listFileUploader(FileUploaderVO fileUploader);
}