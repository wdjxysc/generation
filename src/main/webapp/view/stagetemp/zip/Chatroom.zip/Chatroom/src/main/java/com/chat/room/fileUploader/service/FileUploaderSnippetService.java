package com.chat.room.fileUploader.service;

import com.chat.room.fileUploader.vo.FileUploaderSnippetVO;
import java.util.List;
/**   
 * @formatClassName:  FileUploaderSnippetDAO   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月06日 03:34:150
 * @Copyright: generation
 */
public interface FileUploaderSnippetService {
	
	void insertFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
	
	void deleteFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
	
	void updateFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
	
	List<FileUploaderSnippetVO> listFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet);
}