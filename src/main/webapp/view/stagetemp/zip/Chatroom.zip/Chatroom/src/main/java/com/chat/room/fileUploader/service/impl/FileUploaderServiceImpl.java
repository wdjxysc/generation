package com.chat.room.fileUploader.service.impl;

import com.chat.room.fileUploader.vo.FileUploaderVO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.chat.room.fileUploader.service.FileUploaderService;
import com.chat.room.fileUploader.dao.FileUploaderDAO;

/**   
 * @formatClassName:  FileUploaderServiceImpl   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月06日 03:34:157
 * @Copyright: generation
 */
@Service
public class FileUploaderServiceImpl implements FileUploaderService{
	
	@Autowired
	private FileUploaderDAO fileUploaderDAO;
	
	@Override
	public void insertFileUploader(FileUploaderVO fileUploader){
		fileUploaderDAO.insertFileUploader(fileUploader);
	}
	
	@Override
	public void deleteFileUploader(FileUploaderVO fileUploader){
		fileUploaderDAO.deleteFileUploader(fileUploader);
	}
	
	@Override
	public void updateFileUploader(FileUploaderVO fileUploader){
		fileUploaderDAO.updateFileUploader(fileUploader);
	}
	
	@Override
	public List<FileUploaderVO> listFileUploader(FileUploaderVO fileUploader){
		List<FileUploaderVO> list = fileUploaderDAO.listFileUploader(fileUploader);
		return list;
	}
}