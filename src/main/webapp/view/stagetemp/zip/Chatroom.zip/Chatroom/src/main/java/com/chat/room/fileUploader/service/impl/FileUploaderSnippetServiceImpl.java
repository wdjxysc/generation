package com.chat.room.fileUploader.service.impl;

import com.chat.room.fileUploader.vo.FileUploaderSnippetVO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.chat.room.fileUploader.service.FileUploaderSnippetService;
import com.chat.room.fileUploader.dao.FileUploaderSnippetDAO;

/**   
 * @formatClassName:  FileUploaderSnippetServiceImpl   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月06日 03:34:152
 * @Copyright: generation
 */
@Service
public class FileUploaderSnippetServiceImpl implements FileUploaderSnippetService{
	
	@Autowired
	private FileUploaderSnippetDAO fileUploaderSnippetDAO;
	
	@Override
	public void insertFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet){
		fileUploaderSnippetDAO.insertFileUploaderSnippet(fileUploaderSnippet);
	}
	
	@Override
	public void deleteFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet){
		fileUploaderSnippetDAO.deleteFileUploaderSnippet(fileUploaderSnippet);
	}
	
	@Override
	public void updateFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet){
		fileUploaderSnippetDAO.updateFileUploaderSnippet(fileUploaderSnippet);
	}
	
	@Override
	public List<FileUploaderSnippetVO> listFileUploaderSnippet(FileUploaderSnippetVO fileUploaderSnippet){
		List<FileUploaderSnippetVO> list = fileUploaderSnippetDAO.listFileUploaderSnippet(fileUploaderSnippet);
		return list;
	}
}