package com.chat.room.fileUploader.vo;
 
 
public class FileUploaderSnippetVO {
 
	/**
	 * id
	 */
 	private Long id;
 	
	/**
	 * 批次号ID
	 */
 	private Long batchId;
 	
	/**
	 * 片段序号
	 */
 	private Integer fileSnippetOrder;
 	
 	public Long getId() {
 		return id;
 	}
 	
 	public void setId(Long id) {
 		this.id = id;
 	}
 	
 	public Long getBatchId() {
 		return batchId;
 	}
 	
 	public void setBatchId(Long batchId) {
 		this.batchId = batchId;
 	}
 	
 	public Integer getFileSnippetOrder() {
 		return fileSnippetOrder;
 	}
 	
 	public void setFileSnippetOrder(Integer fileSnippetOrder) {
 		this.fileSnippetOrder = fileSnippetOrder;
 	}
 	
	@Override
	public String toString() {
		return "FileUploaderSnippetVO :" + "，id=" + id  + "，batchId=" + batchId  + "，fileSnippetOrder=" + fileSnippetOrder ;
	}

}