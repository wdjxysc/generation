package com.chat.room.fileUploader.vo;
 
import java.util.Date;
 
public class FileUploaderVO {
 
	/**
	 * 文件ID
	 */
 	private Long id;
 	
	/**
	 * 文件名
	 */
 	private String name;
 	
	/**
	 * 文件类型
	 */
 	private String suffix;
 	
	/**
	 * 文件大小
	 */
 	private Integer size;
 	
	/**
	 * 上传人员
	 */
 	private Long userIdCreate;
 	
	/**
	 * 上传人员姓名
	 */
 	private String userNameCreate;
 	
	/**
	 * 上传时间
	 */
 	private Date gmtCreate;
 	
 	public Long getId() {
 		return id;
 	}
 	
 	public void setId(Long id) {
 		this.id = id;
 	}
 	
 	public String getName() {
 		return name;
 	}
 	
 	public void setName(String name) {
 		this.name = name;
 	}
 	
 	public String getSuffix() {
 		return suffix;
 	}
 	
 	public void setSuffix(String suffix) {
 		this.suffix = suffix;
 	}
 	
 	public Integer getSize() {
 		return size;
 	}
 	
 	public void setSize(Integer size) {
 		this.size = size;
 	}
 	
 	public Long getUserIdCreate() {
 		return userIdCreate;
 	}
 	
 	public void setUserIdCreate(Long userIdCreate) {
 		this.userIdCreate = userIdCreate;
 	}
 	
 	public String getUserNameCreate() {
 		return userNameCreate;
 	}
 	
 	public void setUserNameCreate(String userNameCreate) {
 		this.userNameCreate = userNameCreate;
 	}
 	
 	public Date getGmtCreate() {
 		return gmtCreate;
 	}
 	
 	public void setGmtCreate(Date gmtCreate) {
 		this.gmtCreate = gmtCreate;
 	}
 	
	@Override
	public String toString() {
		return "FileUploaderVO :" + "，id=" + id  + "，name=" + name  + "，suffix=" + suffix  + "，size=" + size  + "，userIdCreate=" + userIdCreate  + "，userNameCreate=" + userNameCreate  + "，gmtCreate=" + gmtCreate ;
	}

}