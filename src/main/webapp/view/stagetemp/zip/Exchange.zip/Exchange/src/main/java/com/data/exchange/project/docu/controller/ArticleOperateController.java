package com.data.exchange.docu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import com.data.exchange.docu.service.ArticleOperateService;
import com.data.exchange.docu.vo.ArticleOperateVO;
import java.util.List;
import com.data.exchange.framework.config.ResponseModel;




@RequestMapping("/articleOperate")
@Controller
public class ArticleOperateController {

	@Autowired
	private ArticleOperateService articleOperateService;
	
	@RequestMapping(value="/insert.do", method=RequestMethod.PUT)
	@ResponseBody
	public ResponseModel insertArticleOperate(ArticleOperateVO articleOperate, HttpServletRequest request, HttpServletResponse response){
		articleOperateService.insertArticleOperate(articleOperate);
		return ResponseModel.success("新增成功");
	}
	
	
	@RequestMapping(value="/delete.do", method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseModel deleteArticleOperate(ArticleOperateVO articleOperate, HttpServletRequest request, HttpServletResponse response){
		articleOperateService.deleteArticleOperate(articleOperate);
		return ResponseModel.success("删除成功");
	}
	
	
	@RequestMapping(value="/update.do", method=RequestMethod.POST)
	@ResponseBody
	public ResponseModel updateArticleOperate(ArticleOperateVO articleOperate, HttpServletRequest request, HttpServletResponse response){
		articleOperateService.updateArticleOperate(articleOperate);
		return ResponseModel.success("更新成功");
	}
	
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	@ResponseBody
	public ResponseModel listArticleOperate(ArticleOperateVO articleOperate, HttpServletRequest request, HttpServletResponse response){
		List<ArticleOperateVO> list = articleOperateService.listArticleOperate(articleOperate);
		return ResponseModel.success(list);
	}
}

