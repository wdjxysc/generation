package com.data.exchange.docu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import com.data.exchange.docu.service.ArticleSeqService;
import com.data.exchange.docu.vo.ArticleSeqVO;
import java.util.List;
import com.data.exchange.framework.config.ResponseModel;




@RequestMapping("/articleSeq")
@Controller
public class ArticleSeqController {

	@Autowired
	private ArticleSeqService articleSeqService;
	
	@RequestMapping(value="/insert.do", method=RequestMethod.PUT)
	@ResponseBody
	public ResponseModel insertArticleSeq(ArticleSeqVO articleSeq, HttpServletRequest request, HttpServletResponse response){
		articleSeqService.insertArticleSeq(articleSeq);
		return ResponseModel.success("新增成功");
	}
	
	
	@RequestMapping(value="/delete.do", method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseModel deleteArticleSeq(ArticleSeqVO articleSeq, HttpServletRequest request, HttpServletResponse response){
		articleSeqService.deleteArticleSeq(articleSeq);
		return ResponseModel.success("删除成功");
	}
	
	
	@RequestMapping(value="/update.do", method=RequestMethod.POST)
	@ResponseBody
	public ResponseModel updateArticleSeq(ArticleSeqVO articleSeq, HttpServletRequest request, HttpServletResponse response){
		articleSeqService.updateArticleSeq(articleSeq);
		return ResponseModel.success("更新成功");
	}
	
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	@ResponseBody
	public ResponseModel listArticleSeq(ArticleSeqVO articleSeq, HttpServletRequest request, HttpServletResponse response){
		List<ArticleSeqVO> list = articleSeqService.listArticleSeq(articleSeq);
		return ResponseModel.success(list);
	}
}

