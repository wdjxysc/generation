package com.data.exchange.docu.service;

import com.data.exchange.docu.vo.ArticleOperateVO;
import java.util.List;
/**   
 * @formatClassName:  ArticleOperateDAO   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月08日 04:10:46
 * @Copyright: generation
 */
public interface ArticleOperateService {
	/*
	 * @Title: insertArticleOperate
	 * @Description:新增
	 * @author: generation
	 * @date:   2019年07月08日 04:10:46
	 * @param articleOperate 新增内容
	 */
	void insertArticleOperate(ArticleOperateVO articleOperate);
	
	/*
	 * @Title: deleteArticleOperate
	 * @Description:删除
	 * @author: generation
	 * @date:   2019年07月08日 04:10:46
	 * @param articleOperate 删除对象条件
	 */
	void deleteArticleOperate(ArticleOperateVO articleOperate);
	
	/*
	 * @Title: updateArticleOperate
	 * @Description:更新
	 * @author: generation
	 * @date:   2019年07月08日 04:10:46
	 * @param articleOperate 更新条件及目标对象标识
	 */
	void updateArticleOperate(ArticleOperateVO articleOperate);
	
	/*
	 * @Title: listArticleOperate
	 * @Description:查询列表
	 * @author: generation
	 * @date:   2019年07月08日 04:10:46
	 * @param articleOperate 查询条件
	 * @return List<ArticleOperateVO> 返回结果
	 */
	List<ArticleOperateVO> listArticleOperate(ArticleOperateVO articleOperate);
}