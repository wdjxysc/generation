package com.data.exchange.docu.service;

import com.data.exchange.docu.vo.ArticleSeqVO;
import java.util.List;
/**   
 * @formatClassName:  ArticleSeqDAO   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月08日 04:10:57
 * @Copyright: generation
 */
public interface ArticleSeqService {
	/*
	 * @Title: insertArticleSeq
	 * @Description:新增
	 * @author: generation
	 * @date:   2019年07月08日 04:10:57
	 * @param articleSeq 新增内容
	 */
	void insertArticleSeq(ArticleSeqVO articleSeq);
	
	/*
	 * @Title: deleteArticleSeq
	 * @Description:删除
	 * @author: generation
	 * @date:   2019年07月08日 04:10:57
	 * @param articleSeq 删除对象条件
	 */
	void deleteArticleSeq(ArticleSeqVO articleSeq);
	
	/*
	 * @Title: updateArticleSeq
	 * @Description:更新
	 * @author: generation
	 * @date:   2019年07月08日 04:10:57
	 * @param articleSeq 更新条件及目标对象标识
	 */
	void updateArticleSeq(ArticleSeqVO articleSeq);
	
	/*
	 * @Title: listArticleSeq
	 * @Description:查询列表
	 * @author: generation
	 * @date:   2019年07月08日 04:10:57
	 * @param articleSeq 查询条件
	 * @return List<ArticleSeqVO> 返回结果
	 */
	List<ArticleSeqVO> listArticleSeq(ArticleSeqVO articleSeq);
}