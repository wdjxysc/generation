package com.data.exchange.docu.service.impl;

import com.data.exchange.docu.vo.ArticleOperateVO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.data.exchange.docu.service.ArticleOperateService;
import com.data.exchange.docu.dao.ArticleOperateDAO;

/**   
 * @formatClassName:  ArticleOperateServiceImpl   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月08日 04:10:49
 * @Copyright: generation
 */
@Service
public class ArticleOperateServiceImpl implements ArticleOperateService{
	
	/**
	 *	DAO操作注入对象
	 */
	@Autowired
	private ArticleOperateDAO articleOperateDAO;
	
	/**
	 * <p>Title: insertArticleOperate</p>   
	 * <p>Description: 新增</p>   
	 * @param articleOperate   
	 * @see com.data.exchange.docu.service.ArticleOperateService#insertArticleOperate(com.data.exchange.docu.vo.ArticleOperateVO)
	 */
	@Override
	public void insertArticleOperate(ArticleOperateVO articleOperate){
		articleOperateDAO.insertArticleOperate(articleOperate);
	}
	
	/**
	 * <p>Title: deleteArticleOperate</p>   
	 * <p>Description: 删除</p>   
	 * @param articleOperate   
	 * @see com.data.exchange.docu.service.ArticleOperateService#deleteArticleOperate(com.data.exchange.docu.vo.ArticleOperateVO)
	 */
	@Override
	public void deleteArticleOperate(ArticleOperateVO articleOperate){
		articleOperateDAO.deleteArticleOperate(articleOperate);
	}
	
	/**
	 * <p>Title: updateArticleOperate</p>   
	 * <p>Description: 更新</p>   
	 * @param articleOperate   
	 * @see com.data.exchange.docu.service.ArticleOperateService#updateArticleOperate(com.data.exchange.docu.vo.ArticleOperateVO)
	 */
	@Override
	public void updateArticleOperate(ArticleOperateVO articleOperate){
		articleOperateDAO.updateArticleOperate(articleOperate);
	}
	
	/**
	 * <p>Title: listArticleOperate</p>   
	 * <p>Description: 列表查询</p>   
	 * @param articleOperate   
	 * @see com.data.exchange.docu.service.ArticleOperateService#listArticleOperate(com.data.exchange.docu.vo.ArticleOperateVO)
	 */
	@Override
	public List<ArticleOperateVO> listArticleOperate(ArticleOperateVO articleOperate){
		List<ArticleOperateVO> list = articleOperateDAO.listArticleOperate(articleOperate);
		return list;
	}
}