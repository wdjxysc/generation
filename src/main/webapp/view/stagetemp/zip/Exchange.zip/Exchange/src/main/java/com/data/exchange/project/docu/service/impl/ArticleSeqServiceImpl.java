package com.data.exchange.docu.service.impl;

import com.data.exchange.docu.vo.ArticleSeqVO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.data.exchange.docu.service.ArticleSeqService;
import com.data.exchange.docu.dao.ArticleSeqDAO;

/**   
 * @formatClassName:  ArticleSeqServiceImpl   
 * @Description:TODO    
 * @author: generation
 * @date:   2019年07月08日 04:10:57
 * @Copyright: generation
 */
@Service
public class ArticleSeqServiceImpl implements ArticleSeqService{
	
	/**
	 *	DAO操作注入对象
	 */
	@Autowired
	private ArticleSeqDAO articleSeqDAO;
	
	/**
	 * <p>Title: insertArticleSeq</p>   
	 * <p>Description: 新增</p>   
	 * @param articleSeq   
	 * @see com.data.exchange.docu.service.ArticleSeqService#insertArticleSeq(com.data.exchange.docu.vo.ArticleSeqVO)
	 */
	@Override
	public void insertArticleSeq(ArticleSeqVO articleSeq){
		articleSeqDAO.insertArticleSeq(articleSeq);
	}
	
	/**
	 * <p>Title: deleteArticleSeq</p>   
	 * <p>Description: 删除</p>   
	 * @param articleSeq   
	 * @see com.data.exchange.docu.service.ArticleSeqService#deleteArticleSeq(com.data.exchange.docu.vo.ArticleSeqVO)
	 */
	@Override
	public void deleteArticleSeq(ArticleSeqVO articleSeq){
		articleSeqDAO.deleteArticleSeq(articleSeq);
	}
	
	/**
	 * <p>Title: updateArticleSeq</p>   
	 * <p>Description: 更新</p>   
	 * @param articleSeq   
	 * @see com.data.exchange.docu.service.ArticleSeqService#updateArticleSeq(com.data.exchange.docu.vo.ArticleSeqVO)
	 */
	@Override
	public void updateArticleSeq(ArticleSeqVO articleSeq){
		articleSeqDAO.updateArticleSeq(articleSeq);
	}
	
	/**
	 * <p>Title: listArticleSeq</p>   
	 * <p>Description: 列表查询</p>   
	 * @param articleSeq   
	 * @see com.data.exchange.docu.service.ArticleSeqService#listArticleSeq(com.data.exchange.docu.vo.ArticleSeqVO)
	 */
	@Override
	public List<ArticleSeqVO> listArticleSeq(ArticleSeqVO articleSeq){
		List<ArticleSeqVO> list = articleSeqDAO.listArticleSeq(articleSeq);
		return list;
	}
}