package com.data.exchange.docu.vo;
 
import java.util.Date;
 
public class ArticleOperateVO {
 
	/**
	 * 流水id
	 */
 	private Long id;
 	
	/**
	 * 物品id
	 */
 	private Long articleId;
 	
	/**
	 * 操作类型 1.入库 2.出库 3.借出 4.归还
	 */
 	private Integer operateType;
 	
	/**
	 * 操作时间
	 */
 	private Date operateTime;
 	
	/**
	 * 操作人id
	 */
 	private String operatePerson;
 	
	/**
	 * 操作数据数量
	 */
 	private Integer operateNum;
 	
	/**
	 * 物品操作编号
	 */
 	private String operateNo;
 	
 	public Long getId() {
 		return id;
 	}
 	
 	public void setId(Long id) {
 		this.id = id;
 	}
 	
 	public Long getArticleId() {
 		return articleId;
 	}
 	
 	public void setArticleId(Long articleId) {
 		this.articleId = articleId;
 	}
 	
 	public Integer getOperateType() {
 		return operateType;
 	}
 	
 	public void setOperateType(Integer operateType) {
 		this.operateType = operateType;
 	}
 	
 	public Date getOperateTime() {
 		return operateTime;
 	}
 	
 	public void setOperateTime(Date operateTime) {
 		this.operateTime = operateTime;
 	}
 	
 	public String getOperatePerson() {
 		return operatePerson;
 	}
 	
 	public void setOperatePerson(String operatePerson) {
 		this.operatePerson = operatePerson;
 	}
 	
 	public Integer getOperateNum() {
 		return operateNum;
 	}
 	
 	public void setOperateNum(Integer operateNum) {
 		this.operateNum = operateNum;
 	}
 	
 	public String getOperateNo() {
 		return operateNo;
 	}
 	
 	public void setOperateNo(String operateNo) {
 		this.operateNo = operateNo;
 	}
 	
	@Override
	public String toString() {
		return "ArticleOperateVO :" + "，id=" + id  + "，articleId=" + articleId  + "，operateType=" + operateType  + "，operateTime=" + operateTime  + "，operatePerson=" + operatePerson  + "，operateNum=" + operateNum  + "，operateNo=" + operateNo ;
	}

}