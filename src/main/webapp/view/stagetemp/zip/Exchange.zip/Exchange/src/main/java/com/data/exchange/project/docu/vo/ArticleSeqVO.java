package com.data.exchange.docu.vo;
 
 
public class ArticleSeqVO {
 
	/**
	 * 
	 */
 	private String name;
 	
	/**
	 * 
	 */
 	private Integer startValue;
 	
	/**
	 * 
	 */
 	private Integer incrementValue;
 	
 	public String getName() {
 		return name;
 	}
 	
 	public void setName(String name) {
 		this.name = name;
 	}
 	
 	public Integer getStartValue() {
 		return startValue;
 	}
 	
 	public void setStartValue(Integer startValue) {
 		this.startValue = startValue;
 	}
 	
 	public Integer getIncrementValue() {
 		return incrementValue;
 	}
 	
 	public void setIncrementValue(Integer incrementValue) {
 		this.incrementValue = incrementValue;
 	}
 	
	@Override
	public String toString() {
		return "ArticleSeqVO :" + "，name=" + name  + "，startValue=" + startValue  + "，incrementValue=" + incrementValue ;
	}

}